import scipy.io
import numpy as np  # This line imports the NumPy library and allows you to refer to it as 'np'


import numpy as np

# Načítanie 3D matice zo súboru .npy
matrix_3dUpravena = np.load('upravena_mapa.npy')

# Zobrazenie niektorých základných informácií o matici
print(matrix_3dUpravena.shape)  # Vypíše rozmery matice
print(matrix_3dUpravena.dtype)  # Vypíše dátový typ prvkov matice
print(np.unique(matrix_3dUpravena))  # Vypíše unikátne hodnoty v matici, teda by mali byť [0, 1]



# Save the 3D matrix as a .mat file
scipy.io.savemat('matrix_3dUpravena.mat', {'matrix_3dUpravena': matrix_3dUpravena})
