import numpy as np

# Cesta k pôvodnému .pcd súboru
pcd_file_path = 'map.pcd'

# Načítanie obsahu .pcd súboru
with open(pcd_file_path, 'r') as file:
    pcd_data = file.readlines()

# Hľadanie konca hlavičky súboru .pcd
header_end_index = 0
for i, line in enumerate(pcd_data):
    if line.startswith('DATA'):
        header_end_index = i
        break

# Extrahovanie bodov zo súboru .pcd
points = []
for line in pcd_data[header_end_index + 1:]:
    if line.strip():  # Preskočenie prázdnych riadkov
        parts = line.split()
        points.append([float(parts[0]), float(parts[1]), float(parts[2])])

# Konverzia bodov do numpy pola
points_np = np.array(points)

# Rozlíšenie pre 3D maticu
resolution = 0.1

# Výpočet rozmerov matice
x_min, y_min, z_min = np.min(points_np, axis=0)
x_max, y_max, z_max = np.max(points_np, axis=0)

x_size = int((x_max - x_min) / resolution) + 1
y_size = int((y_max - y_min) / resolution) + 1
z_size = int((z_max - z_min) / resolution) + 1

# Inicializácia 3D matice nulami
matrix_3d = np.zeros((x_size, y_size, z_size), dtype=np.uint8)

# Naplnenie 3D matice hodnotami kde sú prekážky
for point in points_np:
    x_index = int((point[0] - x_min) / resolution)
    y_index = int((point[1] - y_min) / resolution)
    z_index = int((point[2] - z_min) / resolution)
    matrix_3d[x_index, y_index, z_index] = 1

# Uloženie 3D matice do .npy súboru
npy_file_path = 'matrix_3d.npy'
np.save(npy_file_path, matrix_3d)
