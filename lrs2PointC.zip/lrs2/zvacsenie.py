import numpy as np
from scipy.ndimage import binary_dilation

def zvacsi_prekazky_3d(mapa, polomer):
    # Vytvorenie štruktúrneho prvku pre 3D dilatáciu
    struktura = np.ones((2*polomer + 1, 2*polomer + 1, 2*polomer + 1))
    # Použitie dilatácie na zväčšenie prekážok
    nova_mapa = binary_dilation(mapa, structure=struktura).astype(mapa.dtype)
    return nova_mapa

# Načítanie mapy
mapa = np.load('matrix_3d.npy')

# Zväčšenie prekážok
PolomerPrekazky = 1
upravena_mapa = zvacsi_prekazky_3d(mapa, PolomerPrekazky)

# Uloženie upravenej mapy
np.save('upravena_mapa.npy', upravena_mapa)
