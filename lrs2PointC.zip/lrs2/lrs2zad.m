load('matrix_3dUpravena.mat');

% Assuming matrix_3d is already in the workspace
[x, y, z] = ind2sub(size(matrix_3dUpravena), find(matrix_3dUpravena == 1));

% Create a scatter plot of the obstacle points
scatter3(x, y, z, 'filled');

% Set the axis labels
xlabel('X-axis');
ylabel('Y-axis');
zlabel('Z-axis');

% Adjust the view
axis equal;
grid on;
rotate3d on; % Allows you to interactively rotate the plot in 3D
