import matplotlib.pyplot as plt
import numpy as np

# Načítanie pôvodnej a upravenej mapy
original_mapa = np.load('matrix_3d.npy')
upravena_mapa = np.load('upravena_mapa.npy')

# Výber vrstvy na zobrazenie (napríklad vrstva v strede 3D poľa)
vrstva = original_mapa.shape[0] // 2

# Vizualizácia pôvodnej vrstvy
plt.subplot(1, 2, 1)
plt.imshow(original_mapa[vrstva], cmap='gray')
plt.title('Pôvodná Mapa')

# Vizualizácia upravenej vrstvy
plt.subplot(1, 2, 2)
plt.imshow(upravena_mapa[vrstva], cmap='gray')
plt.title('Upravená Mapa')

plt.show()
